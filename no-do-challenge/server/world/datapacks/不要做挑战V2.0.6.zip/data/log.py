import os

# 获取当前工作目录
current_directory = os.getcwd()

# 遍历当前目录及所有子目录
for root, dirs, files in os.walk(current_directory):
    for filename in files:
        if filename.endswith('.mcfunction'):
            file_path = os.path.join(root, filename)
            # 计算相对路径
            relative_path = os.path.relpath(file_path, current_directory)

            # 读取原文件内容
            with open(file_path, 'r', encoding='utf-8') as file:
                original_content = file.readlines()

            # 创建新的内容，替换反斜杠为正斜杠
            relative_path = relative_path.replace('\\', '/')
            new_content = [f'tellraw @a[tag=log] "{relative_path}"\n'] + original_content

            # 写入新的内容到文件
            with open(file_path, 'w', encoding='utf-8') as file:
                file.writelines(new_content)

print("所有.mcfunction文件的第一行已更新，包含相对路径，斜杠已替换。")