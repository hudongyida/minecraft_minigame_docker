import os

# 获取当前工作目录
current_directory = os.getcwd()

# 遍历当前目录及所有子目录
for root, dirs, files in os.walk(current_directory):
    for filename in files:
        if filename.endswith('.mcfunction'):
            file_path = os.path.join(root, filename)
            # 计算相对路径
            relative_path = os.path.relpath(file_path, current_directory)
            # 替换反斜杠为正斜杠
            relative_path = relative_path.replace('\\', '/')
            expected_line = f'tellraw @a[tag=log] "{relative_path}"\n'

            # 读取原文件内容
            with open(file_path, 'r', encoding='utf-8') as file:
                original_content = file.readlines()

            # 检查并删除第一行
            if original_content and original_content[0] == expected_line:
                new_content = original_content[1:]  # 删除第一行
            else:
                new_content = original_content  # 保持原内容不变

            # 写入新的内容到文件
            with open(file_path, 'w', encoding='utf-8') as file:
                file.writelines(new_content)

print("所有.mcfunction文件的第一行已恢复到原始状态，仅删除添加的行。")